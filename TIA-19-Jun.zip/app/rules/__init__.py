"""Deterministic compliance decision rules."""

